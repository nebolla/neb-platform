--
-- PostgreSQL database dump
--

\restrict OjwDea5igkLpPDaGWg2SMHD6c8WsQuEIerUWd3EAOTgRLTyMQSJKVNwGTWYVdDK

-- Dumped from database version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Chain; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Chain" AS ENUM (
    'TRC20',
    'BEP20'
);


ALTER TYPE public."Chain" OWNER TO postgres;

--
-- Name: LedgerType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."LedgerType" AS ENUM (
    'CREDIT',
    'DEBIT'
);


ALTER TYPE public."LedgerType" OWNER TO postgres;

--
-- Name: PurchaseStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PurchaseStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."PurchaseStatus" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'PARTNER',
    'ADMIN',
    'SUPER_ADMIN'
);


ALTER TYPE public."Role" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: EventOutbox; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EventOutbox" (
    id text NOT NULL,
    type text NOT NULL,
    payload jsonb NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    retries integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."EventOutbox" OWNER TO postgres;

--
-- Name: Notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    audience text DEFAULT 'ALL'::text NOT NULL,
    "userId" text
);


ALTER TABLE public."Notification" OWNER TO postgres;

--
-- Name: NotificationRead; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NotificationRead" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "notificationId" text NOT NULL,
    "readAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."NotificationRead" OWNER TO postgres;

--
-- Name: PoolAccount; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PoolAccount" (
    id text NOT NULL,
    name text NOT NULL,
    balance numeric(38,2) DEFAULT 0 NOT NULL
);


ALTER TABLE public."PoolAccount" OWNER TO postgres;

--
-- Name: PoolLedger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PoolLedger" (
    id text NOT NULL,
    "poolId" text NOT NULL,
    event text NOT NULL,
    amount numeric(38,2) NOT NULL,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PoolLedger" OWNER TO postgres;

--
-- Name: Purchase; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Purchase" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "amountUsd" numeric(38,2) NOT NULL,
    chain public."Chain" NOT NULL,
    "proofUrl" text NOT NULL,
    "txHash" text,
    status public."PurchaseStatus" DEFAULT 'PENDING'::public."PurchaseStatus" NOT NULL,
    "reviewedBy" text,
    "reviewedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Purchase" OWNER TO postgres;

--
-- Name: Setting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Setting" (
    key text NOT NULL,
    val text NOT NULL
);


ALTER TABLE public."Setting" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    "partnerId" text NOT NULL,
    email text NOT NULL,
    name text,
    "passwordHash" text NOT NULL,
    role public."Role" DEFAULT 'PARTNER'::public."Role" NOT NULL,
    "referralCode" text NOT NULL,
    "referrerId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "addressLine1" text,
    "addressLine2" text,
    city text,
    country text,
    dob timestamp(3) without time zone,
    phone text,
    "postalCode" text,
    state text,
    address1 text,
    address2 text,
    zip text
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: Wallet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Wallet" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    balance numeric(38,2) DEFAULT 0 NOT NULL
);


ALTER TABLE public."Wallet" OWNER TO postgres;

--
-- Name: WalletLedger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WalletLedger" (
    id text NOT NULL,
    "walletId" text NOT NULL,
    type public."LedgerType" NOT NULL,
    event text NOT NULL,
    amount numeric(38,2) NOT NULL,
    meta jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."WalletLedger" OWNER TO postgres;

--
-- Name: Withdrawal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Withdrawal" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "amountReq" numeric(38,2) NOT NULL,
    "feePercent" numeric(5,2) DEFAULT 5.00 NOT NULL,
    "feeAmount" numeric(38,2) DEFAULT 0 NOT NULL,
    "amountPaid" numeric(38,2) DEFAULT 0 NOT NULL,
    chain public."Chain" NOT NULL,
    "toAddress" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "processedBy" text,
    "processedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Withdrawal" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Data for Name: EventOutbox; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EventOutbox" (id, type, payload, status, retries, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notification" (id, "createdAt", title, body, audience, "userId") FROM stdin;
cmg1pc9ak000178gktxikcyv2	2025-09-27 03:19:15.98	Hi	Hello	ALL	\N
cmg1pcy9c000378gkecphym07	2025-09-27 03:19:48.337	Hi	Hello	ALL	\N
cmg1pxien000178mbyqmobyil	2025-09-27 03:35:47.567	Hi	Hello \r\nGood Morning	ALL	\N
\.


--
-- Data for Name: NotificationRead; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NotificationRead" (id, "userId", "notificationId", "readAt") FROM stdin;
cmg1qbu1d0001787qedwp04tj	cmg06jn7u000078oo96so7cut	cmg1pc9ak000178gktxikcyv2	2025-09-27 03:46:55.825
\.


--
-- Data for Name: PoolAccount; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PoolAccount" (id, name, balance) FROM stdin;
cmfzl5dd8000178cjnih53lg9	VIP	5.00
cmfzl5dda000278cjovseqnf9	ELITE	5.00
cmfzl5ddc000378cjnmioy1r3	WITHDRAWAL_FEE	0.50
\.


--
-- Data for Name: PoolLedger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PoolLedger" (id, "poolId", event, amount, meta, "createdAt") FROM stdin;
cmg09t73u000578ud382cthfd	cmfzl5dd8000178cjnih53lg9	ACCRUAL	2.50	{"purchaseId": "cmg09h16l0001785s2xe5zchb"}	2025-09-26 03:16:46.267
cmg09t73x000678udxlmbiimx	cmfzl5dda000278cjovseqnf9	ACCRUAL	2.50	{"purchaseId": "cmg09h16l0001785s2xe5zchb"}	2025-09-26 03:16:46.269
cmg1m768p000a78vbo408uig7	cmfzl5dd8000178cjnih53lg9	ACCRUAL	2.50	{"purchaseId": "cmg1m5dpu000478vbmksrgwji"}	2025-09-27 01:51:19.897
cmg1m768r000b78vb9sowtish	cmfzl5dda000278cjovseqnf9	ACCRUAL	2.50	{"purchaseId": "cmg1m5dpu000478vbmksrgwji"}	2025-09-27 01:51:19.9
cmg1o8d69000478rq3izc3861	cmfzl5ddc000378cjnmioy1r3	WITHDRAWAL_FEE	0.50	{"user": "NEB-5T5MLH", "withdrawalId": "cmg1nzthk000178ko9kgx45h9"}	2025-09-27 02:48:14.769
\.


--
-- Data for Name: Purchase; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Purchase" (id, "userId", "amountUsd", chain, "proofUrl", "txHash", status, "reviewedBy", "reviewedAt", "createdAt") FROM stdin;
cmg09h16l0001785s2xe5zchb	cmg06jn7u000078oo96so7cut	100.00	BEP20	/api/proofs/af8a297c-a8b1-4eee-8038-c260fedcf496.jpg	\N	APPROVED	NEB-ADMIN	2025-09-26 03:16:46.246	2025-09-26 03:07:18.717
cmg1m5dpu000478vbmksrgwji	cmg1m3bve000078vbi0r0ofrr	100.00	TRC20	/api/proofs/13bb364f-0192-4333-80a9-e135dd23053f.jpg	\N	APPROVED	NEB-ADMIN	2025-09-27 01:51:19.81	2025-09-27 01:49:56.274
\.


--
-- Data for Name: Setting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Setting" (key, val) FROM stdin;
TRC20_USDT	TEP8dnZ4HRYSaqgjWtKjkrRAnBe5WcoEvP
BEP20_USDT	0xB10e828A75eA63795233450EBFFcd521A5b7924E
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, "partnerId", email, name, "passwordHash", role, "referralCode", "referrerId", "createdAt", "updatedAt", "addressLine1", "addressLine2", city, country, dob, phone, "postalCode", state, address1, address2, zip) FROM stdin;
cmfzl5dd3000078cjnqpd6t2y	NEB-ADMIN	admin@nebolla.space	Super Admin	$2b$12$r.gCdGZIi8cN12VUaUHbd.RLM1qGid2xJU9sAtIgfQDRnn8JfljS.	SUPER_ADMIN	admin	\N	2025-09-25 15:46:23.847	2025-09-25 15:46:23.847	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
cmg06jn7u000078oo96so7cut	NEB-5T5MLH	contactcall7777@gmail.com	Osho Dhyan	$2b$12$uFveJNZ440aaChge.0oz/.fATeAcPDsllMWQ/wpsG2kKxVnauDgRC	PARTNER	X70XVZ4B	\N	2025-09-26 01:45:21.739	2025-09-26 01:45:21.739	1016 W Northern Lights Blvd	\N	Anchorage	United States	2000-01-01 00:00:00	987500887711	\t99503	Alaska	\N	\N	\N
cmg1m3bve000078vbi0r0ofrr	NEB-046Y94	contactcall777@gmail.com	Madhu Love	$2b$12$fIo1PXFs10cKOURrULvgYO/sD0lhT70pFtA9S3GtIeXDwmqnyU5C.	PARTNER	FFST96I4	cmg06jn7u000078oo96so7cut	2025-09-27 01:48:20.57	2025-09-27 01:48:20.57	u	q	q	q	2025-09-10 00:00:00	9847281901	q	q	\N	\N	\N
\.


--
-- Data for Name: Wallet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Wallet" (id, "userId", type, balance) FROM stdin;
cmg06jn7u000178oo6in9tg36	cmg06jn7u000078oo96so7cut	NEB	100.00
cmg1m3bve000278vb5obcc6ns	cmg1m3bve000078vbi0r0ofrr	INCOME	0.00
cmg1m3bve000178vbz5zf220o	cmg1m3bve000078vbi0r0ofrr	NEB	100.00
cmg06jn7u000278oo0kkmnw3f	cmg06jn7u000078oo96so7cut	INCOME	0.00
\.


--
-- Data for Name: WalletLedger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WalletLedger" (id, "walletId", type, event, amount, meta, "createdAt") FROM stdin;
cmg09t73k000278udggo7t271	cmg06jn7u000178oo6in9tg36	CREDIT	PurchaseApproved	100.00	{"purchaseId": "cmg09h16l0001785s2xe5zchb"}	2025-09-26 03:16:46.256
cmg1m767c000778vbej32vd7z	cmg1m3bve000178vbz5zf220o	CREDIT	PurchaseApproved	100.00	{"purchaseId": "cmg1m5dpu000478vbmksrgwji"}	2025-09-27 01:51:19.849
cmg1m768x000e78vb6z6gs2va	cmg06jn7u000278oo0kkmnw3f	CREDIT	ReferralL1	10.00	{"from": "NEB-046Y94", "purchaseId": "cmg1m5dpu000478vbmksrgwji"}	2025-09-27 01:51:19.905
cmg1o8d5v000278rq46wu071t	cmg06jn7u000278oo0kkmnw3f	DEBIT	Withdrawal	10.00	{"fee": 0.5, "net": 9.5, "chain": "BEP20", "address": "0x05A5bc620D55708776c8B52f38A3F5bf0b9DC420", "withdrawalId": "cmg1nzthk000178ko9kgx45h9"}	2025-09-27 02:48:14.755
\.


--
-- Data for Name: Withdrawal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Withdrawal" (id, "userId", "amountReq", "feePercent", "feeAmount", "amountPaid", chain, "toAddress", status, "processedBy", "processedAt", "createdAt") FROM stdin;
cmg1nzthk000178ko9kgx45h9	cmg06jn7u000078oo96so7cut	10.00	5.00	0.50	9.50	BEP20	0x05A5bc620D55708776c8B52f38A3F5bf0b9DC420	APPROVED	NEB-ADMIN	2025-09-27 02:48:14.748	2025-09-27 02:41:36.008
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
bcf4039d-ee8f-4e79-b382-201bda0bdc63	3a778ea3db6619da42e6992dcac65e5e05c63d93c3430c97b0bbb1ede7606279	2025-09-25 15:45:31.867627+00	20250925063736_init	\N	\N	2025-09-25 15:45:31.806229+00	1
10d57bd0-ecd5-4a13-aa98-2fd3204f384e	4247f11744e6dddccb4abd3c1ca98accc8032d44f377b7a2e63111e737b0d036	2025-09-26 01:37:42.797861+00	20250926013742_add_profile_fields	\N	\N	2025-09-26 01:37:42.782101+00	1
f28f917c-7e10-4cdf-b774-34cb5e75b63f	391dfcde0193700573b5d8b728ab82725926a346d453c5ee14db0a0d205c808a	2025-09-27 03:04:43.633949+00	20250927030443_notifications	\N	\N	2025-09-27 03:04:43.607985+00	1
57ef06d2-a6cd-4b9c-b197-40f81811d333	7be0557a3780f848042c9d19d82ce46ab8d6cbaf5a8f296731a0e733d66806a6	2025-09-27 07:51:48.866533+00	20250927075148_user_profile_fields	\N	\N	2025-09-27 07:51:48.860564+00	1
\.


--
-- Name: EventOutbox EventOutbox_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EventOutbox"
    ADD CONSTRAINT "EventOutbox_pkey" PRIMARY KEY (id);


--
-- Name: NotificationRead NotificationRead_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationRead"
    ADD CONSTRAINT "NotificationRead_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: PoolAccount PoolAccount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PoolAccount"
    ADD CONSTRAINT "PoolAccount_pkey" PRIMARY KEY (id);


--
-- Name: PoolLedger PoolLedger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PoolLedger"
    ADD CONSTRAINT "PoolLedger_pkey" PRIMARY KEY (id);


--
-- Name: Purchase Purchase_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Purchase"
    ADD CONSTRAINT "Purchase_pkey" PRIMARY KEY (id);


--
-- Name: Setting Setting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Setting"
    ADD CONSTRAINT "Setting_pkey" PRIMARY KEY (key);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: WalletLedger WalletLedger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WalletLedger"
    ADD CONSTRAINT "WalletLedger_pkey" PRIMARY KEY (id);


--
-- Name: Wallet Wallet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Wallet"
    ADD CONSTRAINT "Wallet_pkey" PRIMARY KEY (id);


--
-- Name: Withdrawal Withdrawal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Withdrawal"
    ADD CONSTRAINT "Withdrawal_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: NotificationRead_userId_notificationId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "NotificationRead_userId_notificationId_key" ON public."NotificationRead" USING btree ("userId", "notificationId");


--
-- Name: PoolAccount_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PoolAccount_name_key" ON public."PoolAccount" USING btree (name);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_partnerId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_partnerId_key" ON public."User" USING btree ("partnerId");


--
-- Name: User_referralCode_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_referralCode_key" ON public."User" USING btree ("referralCode");


--
-- Name: Wallet_userId_type_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Wallet_userId_type_key" ON public."Wallet" USING btree ("userId", type);


--
-- Name: NotificationRead NotificationRead_notificationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationRead"
    ADD CONSTRAINT "NotificationRead_notificationId_fkey" FOREIGN KEY ("notificationId") REFERENCES public."Notification"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NotificationRead NotificationRead_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationRead"
    ADD CONSTRAINT "NotificationRead_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PoolLedger PoolLedger_poolId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PoolLedger"
    ADD CONSTRAINT "PoolLedger_poolId_fkey" FOREIGN KEY ("poolId") REFERENCES public."PoolAccount"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Purchase Purchase_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Purchase"
    ADD CONSTRAINT "Purchase_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: WalletLedger WalletLedger_walletId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WalletLedger"
    ADD CONSTRAINT "WalletLedger_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES public."Wallet"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Wallet Wallet_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Wallet"
    ADD CONSTRAINT "Wallet_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Withdrawal Withdrawal_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Withdrawal"
    ADD CONSTRAINT "Withdrawal_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict OjwDea5igkLpPDaGWg2SMHD6c8WsQuEIerUWd3EAOTgRLTyMQSJKVNwGTWYVdDK

